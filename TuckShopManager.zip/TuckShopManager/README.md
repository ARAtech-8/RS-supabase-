# Tuck Shop Manager 2.0 (Android, online, owner + employees)

Stock, sales, profit and cash-flow app for a small shop. Kotlin + Jetpack Compose. Records are saved online in **Supabase**, so they survive a lost phone and can be used on several phones. The owner signs in with an email; employees sign in with **shop code + username + password** made by the owner.

## ONE-TIME SETUP IN SUPABASE (about 5 minutes)
1. Open your Supabase project > **SQL Editor** > **New query**. Paste the whole file `supabase_setup.sql` and press **Run**. It should say "Success". (Run it once on a new project.)
2. **Authentication > Sign In / Providers > Email**: make sure Email is enabled and turn **OFF "Confirm email"**. (Employees have no real email, so this must be off.)
3. Done. The app already contains your project URL and publishable key (`app/src/main/java/com/tuckshop/manager/net/Api.kt`).
   - Never put the **secret / service_role** key in the app, in GitHub, or anywhere you share.
   - The publishable key is safe in the app: the database rules (Row Level Security) decide what each person can see.

## Build the APK
Same as before: `bash build_codespace.sh` in a Codespace (it installs Java 17 itself), or push to GitHub and use Actions > Build APK. Install over the old app; the old phone-only records are kept until you move them (below).

## First use
- **Owner**: open the app > **New shop** tab > shop name, your name, email, password > Create my shop.
- **More > Shop settings**: currency symbol, money at the start, whether employees may sell on credit. If this phone has records from the old version, tap **Move my old records** (once, while the online shop is still empty).
- **More > Your employees > Add an employee**: name, username, password. The app shows the shop code, username and password to give them (Share button).
- Employee: open the app > **Employee** tab > shop code, username, password.

## Who can do what
| | Owner | Employee |
|---|---|---|
| Sell, add customers | yes | yes (credit sales only if the owner allows) |
| Change a sale price while selling | yes | no (list price is forced by the server) |
| Cancel a sale | any | only their own, within 24 hours |
| See products, selling prices, stock levels | yes | yes (no buying prices) |
| Report damaged / expired / missing stock | yes | yes (removing stock only; their name is saved) |
| Add / edit / delete products, import Excel, add stock | yes | no |
| Cost prices, profit, expenses, cash flow, reports, who owes who, owner's money | yes | **no, the server never sends it** |
| See sales | all | only their own, last 2 days |
| Add employees, switch logins off, activity log | yes | no |

This is enforced in the database, not just hidden in the screens: an employee's login physically cannot read costs, expenses or reports.

## Employees' passwords
- Employees can change their own password: **More > My account**.
- If one forgets it: **More > Your employees** > Switch off, then add them again with a new username (the app cannot reset a password without the secret Supabase key, which must never be in the app).
- Switching a login off locks that employee out immediately.

## Free trial and keys (one key per shop)
- The shop gets a 24-hour free trial from the moment it is created (server time, so the phone clock cannot extend it).
- Then the owner sees: "WhatsApp +263 715 048 687 to get key", with the **Shop Code** and an Open WhatsApp button. Employees see "ask your employer".
- Make the key with `keygen.html` (kept OUTSIDE this project; never upload it): type the 6-character Shop Code, press Generate, send the key.
- The owner types the key once. It is saved with the shop, so all phones signed in to that shop are unlocked permanently.
- The key is checked inside the app (not by the server), which is fine for a small paid app but a determined technical person could bypass it.
- The shop code and key are tied together by the secret in `domain/License.kt` and `keygen.html`; both must match. Changing it invalidates old keys.

## Good to know
- The app needs internet. Without it you see the last information and a red bar, and sales are **not** saved (the app tells you), so nothing is half-recorded.
- Lists refresh every minute and after every change; tap **Refresh** to update right away (useful for the owner watching employee sales).
- Reports: Profit and Loss, Cash Flow, What the shop has and owes, Sales by Product, Sales Over Time, **Sales by Employee**, Stock Value, Who Owes Who (PDF/Excel).
- Employee logins use made-up emails like `tsm.<shopcode>.<username>@gmail.com` that never receive mail. If Supabase ever rejects that domain, change `STAFF_EMAIL_DOMAIN` in `Api.kt`.
- Supabase free plan: a project that nobody uses for a week may be paused; open the dashboard and press Restore.
- The app is signed with the fixed key in `app/debug.keystore`; do not delete it.
