@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.AuthState

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun ShopApp(vm: ShopViewModel, st: AuthState.In) {
    val nav = rememberNavController()
    val settings by vm.settings.collectAsState()
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { snack.showSnackbar(it) }
    }

    val owner = st.isOwner
    val tabs = if (owner) listOf(
        NavTab("home", "Home", Icons.Filled.Home),
        NavTab("sell", "Sell", Icons.Filled.ShoppingCart),
        NavTab("stock", "Stock", Icons.Filled.List),
        NavTab("reports", "Reports", Icons.Filled.DateRange),
        NavTab("more", "More", Icons.Filled.Menu)
    ) else listOf(
        NavTab("home", "My day", Icons.Filled.Home),
        NavTab("sell", "Sell", Icons.Filled.ShoppingCart),
        NavTab("stock", "Stock", Icons.Filled.List),
        NavTab("more", "More", Icons.Filled.Menu)
    )
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = tabs.any { it.route == route }

    ProvideSymbol(settings.symbol) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (showBar) {
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(
                Modifier.padding(pad).fillMaxSize()
                    .then(if (showBar) Modifier else Modifier.navigationBarsPadding())
            ) {
                Column(Modifier.fillMaxSize()) {
                OfflineBar(vm)
                NavHost(nav, startDestination = "home", modifier = Modifier.weight(1f)) {
                    composable("home") { if (owner) HomeScreen(vm, nav) else EmployeeHome(vm, nav) }
                    composable("sell") { SellScreen(vm) }
                    composable("stock") { if (owner) StockScreen(vm) else EmployeeStockScreen(vm) }
                    composable("more") { MoreScreen(nav, owner) }
                    composable("sales") { SalesHistoryScreen(vm) { nav.popBackStack() } }
                    composable("account") { AccountScreen(vm, st) { nav.popBackStack() } }
                    composable("help") { HelpScreen { nav.popBackStack() } }
                    // Owner-only screens are not even registered for employees (the server blocks their data as well).
                    if (owner) {
                        composable("reports") { ReportsScreen(vm, nav) }
                        composable("doc/{key}/{period}") { e ->
                            DocScreen(
                                vm,
                                e.arguments?.getString("key") ?: "pnl",
                                e.arguments?.getString("period") ?: "MONTH",
                                onBack = { nav.popBackStack() }
                            )
                        }
                        composable("expenses") { ExpensesScreen(vm) { nav.popBackStack() } }
                        composable("customers") { CustomersScreen(vm) { nav.popBackStack() } }
                        composable("suppliers") { SuppliersScreen(vm) { nav.popBackStack() } }
                        composable("owner") { OwnerScreen(vm) { nav.popBackStack() } }
                        composable("staff") { StaffScreen(vm, st) { nav.popBackStack() } }
                        composable("activity") { ActivityScreen(vm) { nav.popBackStack() } }
                        composable("settings") { SettingsScreen(vm, st) { nav.popBackStack() } }
                    }
                }
                }
            }
        }
    }
}
