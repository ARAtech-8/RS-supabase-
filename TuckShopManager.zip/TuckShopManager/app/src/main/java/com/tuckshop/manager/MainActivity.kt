package com.tuckshop.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.ui.FailedScreen
import com.tuckshop.manager.ui.LicenseGate
import com.tuckshop.manager.ui.LoadingScreen
import com.tuckshop.manager.ui.LoginScreen
import com.tuckshop.manager.ui.NoAccessScreen
import com.tuckshop.manager.ui.ShopApp
import com.tuckshop.manager.ui.TuckShopTheme

class MainActivity : ComponentActivity() {
    private val vm: ShopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TuckShopTheme {
                val state by vm.authState.collectAsState()
                when (val st = state) {
                    is AuthState.Loading -> LoadingScreen()
                    is AuthState.SignedOut -> LoginScreen(vm)
                    is AuthState.NoAccess -> NoAccessScreen(vm, st.isStaffLogin)
                    is AuthState.Failed -> FailedScreen(vm, st.message)
                    is AuthState.In -> LicenseGate(vm, st) { ShopApp(vm, st) }
                }
            }
        }
    }
}
