package com.tuckshop.manager.io

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.tuckshop.manager.domain.Doc
import com.tuckshop.manager.domain.DocRow
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.RowStyle
import com.tuckshop.manager.domain.ShopSettings
import java.io.ByteArrayOutputStream

/** Draws statements onto A4 pages. One or many statements per file. */
object PdfExporter {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 40f

    private val GREEN = 0xFF1B7F4B.toInt()
    private val SECTION_BG = 0xFFE8F3EC.toInt()
    private val HEADER_BG = 0xFFEDEDED.toInt()
    private val TOTAL_BG = 0xFFD9EDE0.toInt()
    private val GREY = 0xFF666666.toInt()

    private fun paint(size: Float, bold: Boolean = false, color: Int = 0xFF222222.toInt(), italic: Boolean = false): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create(
                Typeface.DEFAULT,
                if (bold && italic) Typeface.BOLD_ITALIC else if (bold) Typeface.BOLD else if (italic) Typeface.ITALIC else Typeface.NORMAL
            )
        }

    private class Writer(val shop: ShopSettings, val periodText: String) {
        val pdf = PdfDocument()
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var pageNo = 0
        var y = 0f

        fun startPage() {
            finishPage()
            pageNo++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            page = p
            canvas = p.canvas
            val c = p.canvas
            c.drawText(shop.shopName, MARGIN, MARGIN, paint(11f, bold = true, color = GREEN))
            val right = paint(9f, color = GREY)
            right.textAlign = Paint.Align.RIGHT
            c.drawText(periodText, PAGE_W - MARGIN, MARGIN, right)
            y = MARGIN + 24f
        }

        fun finishPage() {
            val p = page ?: return
            val c = canvas!!
            val foot = paint(8f, color = GREY)
            c.drawText("Made with Tuck Shop Manager  |  " + Fmt.date(System.currentTimeMillis()), MARGIN, PAGE_H - 24f, foot)
            foot.textAlign = Paint.Align.RIGHT
            c.drawText("Page $pageNo", PAGE_W - MARGIN, PAGE_H - 24f, foot)
            pdf.finishPage(p)
            page = null
            canvas = null
        }

        fun ensure(h: Float) {
            if (page == null || y + h > PAGE_H - MARGIN - 20f) startPage()
        }

        fun ellipsize(text: String, p: Paint, width: Float): String {
            if (p.measureText(text) <= width) return text
            val n = p.breakText(text, true, width - p.measureText("..."), null)
            return text.substring(0, maxOf(0, n)) + "..."
        }

        fun wrap(text: String, p: Paint, width: Float): List<String> {
            val lines = ArrayList<String>()
            var cur = StringBuilder()
            for (w in text.split(" ")) {
                val trial = if (cur.isEmpty()) w else cur.toString() + " " + w
                if (p.measureText(trial) > width && cur.isNotEmpty()) {
                    lines.add(cur.toString())
                    cur = StringBuilder(w)
                } else {
                    cur = StringBuilder(trial)
                }
            }
            if (cur.isNotEmpty()) lines.add(cur.toString())
            return lines
        }

        fun drawDoc(doc: Doc) {
            startPage()
            val c = canvas!!
            c.drawText(doc.title, MARGIN, y + 16f, paint(18f, bold = true))
            y += 26f
            c.drawText(periodText, MARGIN, y + 8f, paint(10f, color = GREY))
            y += 16f
            c.drawText(doc.blurb, MARGIN, y + 8f, paint(9f, color = GREY, italic = true))
            y += 20f
            c.drawLine(MARGIN, y, PAGE_W - MARGIN, y, paint(1f, color = GREEN).apply { strokeWidth = 1.5f })
            y += 8f
            for (row in doc.rows) drawRow(row, doc.weights)
        }

        fun drawRow(row: DocRow, weights: List<Float>) {
            val contentW = PAGE_W - 2 * MARGIN
            val totalW = weights.sum()
            val widths = weights.map { contentW * it / totalW }
            val xs = ArrayList<Float>()
            var acc = MARGIN
            for (w in widths) {
                xs.add(acc)
                acc += w
            }
            val bold = row.style == RowStyle.HEADER || row.style == RowStyle.SECTION ||
                row.style == RowStyle.SUBTOTAL || row.style == RowStyle.TOTAL
            val size = if (row.style == RowStyle.TOTAL) 11.5f else 10f

            if (row.style == RowStyle.NOTE) {
                val p = paint(9f, color = GREY, italic = true)
                val lines = wrap(row.cells.firstOrNull() ?: "", p, contentW - 8f)
                ensure(lines.size * 12f + 8f)
                y += 4f
                for (ln in lines) {
                    canvas!!.drawText(ln, MARGIN + 4f, y + 9f, p)
                    y += 12f
                }
                y += 4f
                return
            }

            val h = when (row.style) {
                RowStyle.TOTAL -> 26f
                RowStyle.SECTION, RowStyle.HEADER -> 22f
                else -> 19f
            }
            ensure(h)
            val c = canvas!!
            val bg = when (row.style) {
                RowStyle.SECTION -> SECTION_BG
                RowStyle.HEADER -> HEADER_BG
                RowStyle.TOTAL -> TOTAL_BG
                else -> 0
            }
            if (bg != 0) {
                val fill = Paint().apply { color = bg }
                c.drawRect(MARGIN, y, PAGE_W - MARGIN, y + h, fill)
            }
            if (row.style == RowStyle.SUBTOTAL || row.style == RowStyle.TOTAL) {
                val line = Paint().apply { color = 0xFF999999.toInt(); strokeWidth = 0.7f }
                c.drawLine(MARGIN, y, PAGE_W - MARGIN, y, line)
            }
            val p = paint(size, bold = bold, color = if (row.style == RowStyle.SECTION) GREEN else 0xFF222222.toInt())
            val baseline = y + h / 2f + size / 3f
            for ((i, cell) in row.cells.withIndex()) {
                if (i >= xs.size) break
                if (cell.isEmpty()) continue
                if (i == 0) {
                    val maxW = if (row.cells.drop(1).all { it.isEmpty() }) contentW else widths[0] - 8f
                    c.drawText(ellipsize(cell, p, maxW), xs[0] + 4f, baseline, p)
                } else {
                    val rp = paint(size, bold = bold, color = if (cell.startsWith("-")) 0xFFB3261E.toInt() else 0xFF222222.toInt())
                    rp.textAlign = Paint.Align.RIGHT
                    c.drawText(ellipsize(cell, rp, widths[i] - 8f), xs[i] + widths[i] - 4f, baseline, rp)
                }
            }
            y += h
        }
    }

    fun build(shop: ShopSettings, periodLabel: String, rangeText: String, docs: List<Doc>): ByteArray {
        val w = Writer(shop, "$periodLabel  ($rangeText)")
        for (d in docs) w.drawDoc(d)
        w.finishPage()
        val out = ByteArrayOutputStream()
        w.pdf.writeTo(out)
        w.pdf.close()
        return out.toByteArray()
    }
}
