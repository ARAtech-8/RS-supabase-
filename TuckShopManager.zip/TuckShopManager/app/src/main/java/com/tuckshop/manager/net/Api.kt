package com.tuckshop.manager.net

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** The two values that point the app at your Supabase project. The publishable key is safe to ship in an app. */
object Cloud {
    const val URL = "https://hakgcpevtoxtxzaxgzsc.supabase.co"
    const val KEY = "sb_publishable__ihuuXYtvoaPIAUQHh6w6A_pxOfNkkf"

    /**
     * Employees sign in with shop code + username + password. Supabase wants an email, so the app builds
     * a private one: tsm.<shopcode>.<username>@<this domain>. It never receives mail. If Supabase ever rejects
     * this domain, change it here (and nowhere else).
     */
    const val STAFF_EMAIL_DOMAIN = "gmail.com"

    fun staffEmail(shopCode: String, username: String): String =
        "tsm." + shopCode.trim().lowercase(Locale.US) + "." + username.trim().lowercase(Locale.US) + "@" + STAFF_EMAIL_DOMAIN
}

/** An error with a message that is safe to show the user. */
class ApiException(message: String, val status: Int = 0, val offline: Boolean = false) : Exception(message)

class Session(val access: String, val refresh: String, val expiresAt: Long, val userId: String, val staffLogin: Boolean)

/**
 * Talks to Supabase with plain HTTP, no extra libraries.
 * All data writes are POSTs to /rest/v1/rpc/<function>; reads are GETs on the tables (the database decides what each person may see).
 */
class Api(context: Context) {
    private val prefs = context.getSharedPreferences("cloud_session", Context.MODE_PRIVATE)
    private val lock = Mutex()

    @Volatile var session: Session? = load()
        private set

    /** Server time minus phone time. Lets the app use the server's clock, so changing the phone's clock changes nothing. */
    @Volatile private var clockOffset: Long = prefs.getLong("offset", 0L)

    fun now(): Long = System.currentTimeMillis() + clockOffset

    private fun load(): Session? {
        val a = prefs.getString("access", null) ?: return null
        val r = prefs.getString("refresh", null) ?: return null
        val u = prefs.getString("user", null) ?: return null
        return Session(a, r, prefs.getLong("exp", 0L), u, prefs.getBoolean("staff", false))
    }

    private fun store(s: Session?) {
        session = s
        val e = prefs.edit()
        if (s == null) e.remove("access").remove("refresh").remove("exp").remove("user").remove("staff")
        else e.putString("access", s.access).putString("refresh", s.refresh).putLong("exp", s.expiresAt)
            .putString("user", s.userId).putBoolean("staff", s.staffLogin)
        e.apply()
    }

    fun signOutLocal() = store(null)

    /** Why the last automatic re-login failed (for the error message). */
    @Volatile var lastRefreshError: String? = null

    // ------------------------------------------------------------------------------------------ low level
    private class Reply(val code: Int, val body: String)

    private suspend fun raw(method: String, path: String, body: String?, bearer: String?, extra: Map<String, String> = emptyMap()): Reply =
        withContext(Dispatchers.IO) {
            var c: HttpURLConnection? = null
            try {
                c = URL(Cloud.URL + path).openConnection() as HttpURLConnection
                c.requestMethod = method
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("apikey", Cloud.KEY)
                // The new-style publishable key is not a JWT, so it is only sent as the apikey header.
                if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
                c.setRequestProperty("Accept", "application/json")
                for ((k, v) in extra) c.setRequestProperty(k, v)
                if (body != null) {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val code = c.responseCode
                readServerDate(c)
                val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                Reply(code, text)
            } catch (e: IOException) {
                throw ApiException("No internet connection. Check your data or Wi-Fi and try again.", 0, true)
            } finally {
                c?.disconnect()
            }
        }

    private fun readServerDate(c: HttpURLConnection) {
        val d = c.getHeaderField("Date") ?: return
        try {
            val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
            f.timeZone = TimeZone.getTimeZone("GMT")
            val server = f.parse(d)?.time ?: return
            clockOffset = server - System.currentTimeMillis()
            prefs.edit().putLong("offset", clockOffset).apply()
        } catch (e: Exception) {
        }
    }

    private fun friendly(code: Int, body: String): ApiException {
        var msg = ""
        var kind = ""
        try {
            val j = JSONObject(body)
            msg = j.optString("message").ifBlank { j.optString("msg") }.ifBlank { j.optString("error_description") }
                .ifBlank { j.optString("error") }
            kind = j.optString("error_code").ifBlank { j.optString("code") }
        } catch (e: Exception) {
            msg = body.take(200)
        }
        val low = msg.lowercase(Locale.US)
        val text = when {
            kind == "over_email_send_rate_limit" || low.contains("rate limit") -> "Too many attempts. Please wait a minute and try again."
            low.contains("invalid login") || kind == "invalid_credentials" -> "Wrong details. Check the username/email and password and try again."
            low.contains("already registered") || low.contains("already been registered") || kind == "user_already_exists" ->
                "That name or email is already taken. Please use a different one."
            low.contains("password") && (low.contains("least") || low.contains("short") || low.contains("weak")) ->
                "The password is too short or too easy. Use at least 6 characters."
            low.contains("email not confirmed") -> "This account still needs email confirmation. Turn OFF 'Confirm email' in Supabase (see the setup notes)."
            low.contains("invalid") && low.contains("email") -> "Supabase did not accept the email. Please check it."
            code == 401 || code == 403 -> "Not allowed (" + code + "): " + (if (msg.isBlank()) body.take(160) else msg)
            msg.isBlank() -> "Something went wrong (error $code): " + body.take(160)
            else -> msg
        }
        return ApiException(text, code)
    }

    // ------------------------------------------------------------------------------------------ auth
    private fun readSession(j: JSONObject, staff: Boolean): Session {
        val user = j.optJSONObject("user")
        val uid = user?.optString("id").orEmpty()
        val exp = api0(j)
        return Session(j.getString("access_token"), j.getString("refresh_token"), exp, uid, staff)
    }

    private fun api0(j: JSONObject): Long {
        val inSec = j.optLong("expires_in", 3600L)
        return now() + inSec * 1000L
    }

    /** Result of a sign-up: the new user's id, and whether Supabase also signed them in. */
    class SignUp(val userId: String, val session: Session?)

    /** Creates a login. Does not touch the current session, so an owner can create employee logins. */
    suspend fun signUp(email: String, password: String, staff: Boolean): SignUp {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val r = raw("POST", "/auth/v1/signup", body, null)
        if (r.code !in 200..299) throw friendly(r.code, r.body)
        val j = try { JSONObject(r.body) } catch (e: Exception) { throw ApiException("Supabase sent an unexpected reply to sign-up: " + r.body.take(150)) }
        val user = j.optJSONObject("user") ?: j
        val id = user.optString("id")
        if (id.isBlank()) throw ApiException("Could not create the login. Please try again.")
        // A user with an unconfirmed email comes back without a session: that means "Confirm email" is still ON.
        val s = if (j.has("access_token")) readSession(j.also { if (!it.has("user")) it.put("user", user) }, staff) else null
        return SignUp(id, s)
    }

    suspend fun signIn(email: String, password: String, staff: Boolean): Session {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val r = raw("POST", "/auth/v1/token?grant_type=password", body, null)
        if (r.code !in 200..299) throw friendly(r.code, r.body)
        val s = readSession(JSONObject(r.body), staff)
        store(s)
        return s
    }

    fun adopt(s: Session) = store(s)

    private suspend fun refresh(): Boolean = lock.withLock {
        val cur = session ?: return false
        // Another call may have refreshed while we waited for the lock.
        if (cur.expiresAt - now() > 60_000L) return true
        val r = raw("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", cur.refresh).toString(), null)
        if (r.code !in 200..299) {
            lastRefreshError = "Session refresh failed (" + r.code + "): " + r.body.take(160)
            if (r.code in 400..403) store(null)
            return false
        }
        val j = JSONObject(r.body)
        store(Session(j.getString("access_token"), j.getString("refresh_token"), api0(j), cur.userId, cur.staffLogin))
        return true
    }

    suspend fun changePassword(newPassword: String) {
        val r = authed("PUT", "/auth/v1/user", JSONObject().put("password", newPassword).toString())
        if (r.code !in 200..299) throw friendly(r.code, r.body)
    }

    // ------------------------------------------------------------------------------------------ data
    private suspend fun authed(method: String, path: String, body: String?, extra: Map<String, String> = emptyMap()): Reply {
        var s = session ?: throw ApiException("Please sign in again.", 401)
        if (s.expiresAt - now() < 60_000L) {
            refresh()
            s = session ?: throw ApiException("Please sign in again.", 401)
        }
        var r = raw(method, path, body, s.access, extra)
        if (r.code == 401) {
            if (refresh()) {
                s = session ?: throw ApiException("Please sign in again.", 401)
                r = raw(method, path, body, s.access, extra)
            }
        }
        return r
    }

    /** Reads rows. Example: get("products", "select=*&order=name"). */
    suspend fun get(table: String, query: String): JSONArray {
        val r = authed("GET", "/rest/v1/$table?$query", null)
        if (r.code !in 200..299) throw friendly(r.code, r.body)
        return JSONArray(r.body.ifBlank { "[]" })
    }

    /** Calls a database function and returns whatever it returned (as raw JSON text). */
    suspend fun rpc(fn: String, args: JSONObject = JSONObject()): String {
        val r = authed("POST", "/rest/v1/rpc/$fn", args.toString())
        if (r.code !in 200..299) throw friendly(r.code, r.body)
        return r.body
    }

    suspend fun rpcObject(fn: String, args: JSONObject = JSONObject()): JSONObject = JSONObject(rpc(fn, args))
    suspend fun rpcArray(fn: String, args: JSONObject = JSONObject()): JSONArray = JSONArray(rpc(fn, args))
    suspend fun rpcLong(fn: String, args: JSONObject = JSONObject()): Long = rpc(fn, args).trim().trim('"').toLong()
}
