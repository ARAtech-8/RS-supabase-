@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.Method
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.domain.Fmt

@Composable
fun SellScreen(vm: ShopViewModel) {
    val products by vm.products.collectAsState()
    var query by remember { mutableStateOf("") }
    var showCart by remember { mutableStateOf(false) }

    val shown = products.filter {
        query.isBlank() || it.name.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true)
    }

    ScreenFrame("New sale") {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search items") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
        )
        if (products.isEmpty()) {
            EmptyHint("You have no products yet.\nGo to the Stock tab and add what you sell.")
        } else if (shown.isEmpty()) {
            EmptyHint("Nothing matches \"$query\".")
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(shown, key = { it.id }) { p ->
                val inCart = vm.cart.firstOrNull { it.product.id == p.id }?.qty ?: 0.0
                SellRow(p, inCart) { vm.addToCart(p) }
            }
        }
        if (vm.cart.isNotEmpty()) {
            Button(
                onClick = { showCart = true },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Text(
                    "Review sale  (" + vm.cart.size + (if (vm.cart.size == 1) " item" else " items") + ")   " + money(vm.cartTotal),
                    fontSize = 16.sp
                )
            }
        }
    }

    if (showCart) CartDialog(vm, onClose = { showCart = false })
}

@Composable
private fun SellRow(p: Product, inCart: Double, onTap: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onTap),
        colors = CardDefaults.cardColors(containerColor = if (inCart > 0) Ui.Soft else Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val left = Fmt.qty(maxOf(0.0, p.stockQty)) + " left"
                Text(
                    if (inCart > 0) left + "   |   in sale: " + Fmt.qty(inCart) else left,
                    fontSize = 12.sp,
                    color = if (p.stockQty <= 0) Ui.Bad else if (p.stockQty <= p.reorderLevel) Ui.Warn else Ui.Muted
                )
            }
            Text(money(p.sellPrice), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun CartDialog(vm: ShopViewModel, onClose: () -> Unit) {
    val customers by vm.customers.collectAsState()
    var method by remember { mutableStateOf(Method.CASH) }
    var customerId by remember { mutableStateOf<Long?>(null) }
    var given by remember { mutableStateOf("") }
    var editQty by remember { mutableStateOf(-1) }
    var editPrice by remember { mutableStateOf(-1) }
    var newCustomer by remember { mutableStateOf(false) }

    val total = vm.cartTotal
    val givenNum = given.toNum()

    val empty = vm.cart.isEmpty()
    LaunchedEffect(empty) { if (empty) onClose() }
    if (empty) return

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Review sale", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                vm.cart.forEachIndexed { i, line ->
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(line.product.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 2)
                            Text(money(line.qty * line.price), fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(onClick = { vm.setQty(i, line.qty - 1.0) }) { Text("-") }
                            TextButton(onClick = { editQty = i }) { Text(Fmt.qty(line.qty), fontSize = 18.sp) }
                            OutlinedButton(onClick = { vm.setQty(i, line.qty + 1.0) }) { Text("+") }
                            if (vm.isOwner) TextButton(onClick = { editPrice = i }) { Text("@ " + money(line.price) + "  (change)") }
                            else Text("@ " + money(line.price), Modifier.padding(start = 8.dp, top = 10.dp), color = Ui.Muted)
                        }
                        HorizontalDivider()
                    }
                }
                Text("TOTAL  " + money(total), fontSize = 22.sp, fontWeight = FontWeight.Bold)

                Text("How did the customer pay?", color = Ui.Muted, fontSize = 12.sp)
                ChipChoice(
                    if (vm.canSellOnCredit) listOf("Cash", "Mobile money", "On credit") else listOf("Cash", "Mobile money"),
                    Method.label(method)
                ) { label ->
                    method = when (label) {
                        "Cash" -> Method.CASH
                        "Mobile money" -> Method.MOBILE
                        else -> Method.CREDIT
                    }
                }

                if (method == Method.CASH) {
                    NumInput(given, { given = it }, "Cash received (optional)")
                    if (givenNum != null && givenNum >= total) {
                        Text("Change to give back: " + money(givenNum - total), fontWeight = FontWeight.Bold, color = Ui.Good)
                    } else if (givenNum != null) {
                        Text("That is " + money(total - givenNum) + " short.", color = Ui.Bad)
                    }
                }
                if (method == Method.CREDIT) {
                    Text("Who is taking this on credit?", color = Ui.Muted, fontSize = 12.sp)
                    if (customers.isNotEmpty()) {
                        ChipChoice(customers.map { it.name }, customers.firstOrNull { it.id == customerId }?.name ?: "") { n ->
                            customerId = customers.firstOrNull { it.name == n }?.id
                        }
                    }
                    TextButton(onClick = { newCustomer = true }) { Text("+ Add a new customer") }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    vm.checkout(method, if (method == Method.CREDIT) customerId else null, "") { onClose() }
                },
                enabled = !vm.selling && (method != Method.CREDIT || customerId != null)
            ) { Text(if (vm.selling) "Saving..." else "Sale done") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.cart.clear(); onClose() }) { Text("Clear", color = Ui.Bad) }
                TextButton(onClick = onClose) { Text("Back") }
            }
        }
    )

    if (editQty >= 0 && editQty < vm.cart.size) {
        NumberDialog("How many?", "Quantity", vm.cart[editQty].qty, { editQty = -1 }) {
            vm.setQty(editQty, it); editQty = -1
        }
    }
    if (editPrice >= 0 && editPrice < vm.cart.size) {
        NumberDialog("Price for this sale", "Price each", vm.cart[editPrice].price, { editPrice = -1 }) {
            vm.setPrice(editPrice, it); editPrice = -1
        }
    }
    if (newCustomer) {
        NewCustomerDialog(onDismiss = { newCustomer = false }) { name, phone ->
            vm.go { customerId = vm.repo.addCustomer(name, phone) }
            newCustomer = false
        }
    }
}

@Composable
fun NewCustomerDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    FormDialog("New customer", "Save", onDismiss, { onSave(name, phone) }, confirmEnabled = name.isNotBlank()) {
        TextInput(name, { name = it }, "Name")
        TextInput(phone, { phone = it }, "Phone (optional)")
    }
}
