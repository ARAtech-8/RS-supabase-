@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.Method
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.ReportBundle
import com.tuckshop.manager.domain.compareLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(vm: ShopViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsState()
    val products by vm.products.collectAsState()
    val version by vm.repo.version.collectAsState()
    val bundle by produceState<ReportBundle?>(null, version) { value = try { vm.repo.bundle(Period.TODAY) } catch (e: Exception) { value } }
    val recentFlow = remember { vm.repo.recentSales(5) }
    val recent by recentFlow.collectAsState(initial = emptyList())

    ScreenFrame(settings.shopName, actions = { RefreshAction(vm) }) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                SimpleDateFormat("EEEE, d MMMM", Locale.US).format(Date()),
                color = Ui.Muted
            )

            if (products.isEmpty()) {
                WhiteCard {
                    Text("Welcome!", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Let's start by adding the things you sell. You can type them in one by one, " +
                            "or load a whole list from an Excel file.",
                        Modifier.padding(vertical = 8.dp)
                    )
                    Button(onClick = { nav.navigate("stock") }, modifier = Modifier.fillMaxWidth()) {
                        Text("Add my products")
                    }
                    OutlinedButton(
                        onClick = { nav.navigate("settings") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) { Text("Set shop name and currency first") }
                }
            }

            val trial = LocalTrialMsLeft.current
            if (trial != null) {
                WhiteCard {
                    Text("Free trial: " + trialText(trial), fontWeight = FontWeight.Bold, color = Ui.Warn)
                    Text(
                        "After that, WhatsApp " + com.tuckshop.manager.domain.License.WHATSAPP_DISPLAY + " to get key. Everything you enter stays safe.",
                        fontSize = 12.sp, color = Ui.Muted
                    )
                }
            }

            val b = bundle
            if (b != null) {
                WhiteCard {
                    Text("Sold today", color = Ui.Muted)
                    Text(money(b.summary.sales), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    val ch = changeText(b.summary.sales, b.prev.sales, "than the same time yesterday")
                    if (ch != null) Text(ch.first, color = ch.second, fontSize = 12.sp)
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Profit so far", color = Ui.Muted, fontSize = 12.sp)
                            Text(
                                money(b.summary.profit), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                                color = profitColor(b.summary.profit)
                            )
                            Text("what is left after the goods cost", fontSize = 11.sp, color = Ui.Muted)
                        }
                        Column {
                            Text("Customers served", color = Ui.Muted, fontSize = 12.sp)
                            Text(b.summary.count.toString(), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { nav.navigate("sell") }, modifier = Modifier.weight(1f)) { Text("New sale") }
                FilledTonalButton(onClick = { nav.navigate("stock") }, modifier = Modifier.weight(1f)) { Text("Add stock") }
                FilledTonalButton(onClick = { nav.navigate("expenses") }, modifier = Modifier.weight(1f)) { Text("Expense") }
            }

            if (b != null) {
                val low = b.reorder.size
                val owed = b.position.owedToShop
                val owe = b.position.owedByShop
                if (low > 0 || owed > 0.005 || owe > 0.005) {
                    WhiteCard {
                        Text("Things to look at", fontWeight = FontWeight.Bold)
                        if (low > 0) AlertLine(
                            "$low item" + (if (low == 1) " is" else "s are") + " running low", "See list"
                        ) { nav.navigate("stock") }
                        if (owed > 0.005) AlertLine("Customers owe you " + money(owed), "View") { nav.navigate("customers") }
                        if (owe > 0.005) AlertLine("You owe suppliers " + money(owe), "View") { nav.navigate("suppliers") }
                    }
                }
            }

            if (recent.isNotEmpty()) {
                WhiteCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Latest sales", fontWeight = FontWeight.Bold)
                        Text("See all", color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { nav.navigate("sales") })
                    }
                    recent.forEach { s ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                Fmt.dateTime(s.time) + "  " + Method.label(s.method) + (if (s.voided) "  (cancelled)" else ""),
                                color = if (s.voided) Ui.Muted else Color0
                            )
                            Text(money(s.total), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (b != null && b.summary.count == 0 && products.isNotEmpty()) {
                Text(
                    "No sales yet today. Tap New sale when your first customer buys.",
                    color = Ui.Muted
                )
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.Unspecified

@Composable
private fun AlertLine(text: String, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text, Modifier.weight(1f))
        Text(action, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable(onClick = onClick))
    }
}
