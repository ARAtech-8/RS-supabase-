package com.tuckshop.manager

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tuckshop.manager.data.CartLine
import com.tuckshop.manager.data.Customer
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.data.ShopRepository
import com.tuckshop.manager.net.ApiException
import com.tuckshop.manager.net.AuthManager
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.ShopSettings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(app: Application) : AndroidViewModel(app) {
    private val tsApp = app as TuckShopApp
    val repo: ShopRepository = tsApp.repo
    val auth: AuthManager = tsApp.auth
    val api = tsApp.api

    val authState: StateFlow<AuthState> get() = auth.state

    private val signedIn: AuthState.In? get() = auth.state.value as? AuthState.In

    /** Owners can do everything; employees get a smaller set of screens, and the server enforces it too. */
    val isOwner: Boolean get() = signedIn?.isOwner == true
    val myName: String get() = signedIn?.member?.displayName ?: ""
    val canSellOnCredit: Boolean get() = isOwner || signedIn?.shop?.allowEmployeeCredit == true

    init {
        viewModelScope.launch { auth.start() }
    }

    val products: StateFlow<List<Product>> =
        repo.products.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val customers: StateFlow<List<Customer>> =
        repo.customers.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings: StateFlow<ShopSettings> get() = repo.settings

    /** The sale being built on the Sell screen. Kept here so it survives switching tabs. */
    val cart = mutableStateListOf<CartLine>()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> get() = _messages

    fun say(text: String) {
        _messages.tryEmit(text)
    }

    /** Run something in the background, optionally telling the user when it is done. */
    fun go(done: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                if (done != null) say(done)
            } catch (e: ApiException) {
                if (e.status == 401 && e.message == "Please sign in again.") {
                    auth.sessionExpired()
                    say("Please sign in again.")
                } else say(e.message ?: "Something went wrong.")
            } catch (e: Exception) {
                say("Something went wrong: " + (e.message ?: "unknown error"))
            }
        }
    }

    // ------------------------------------------------------------------ cart
    val cartTotal: Double get() = cart.sumOf { it.qty * it.price }

    fun addToCart(p: Product) {
        val i = cart.indexOfFirst { it.product.id == p.id }
        val newQty = if (i >= 0) cart[i].qty + 1.0 else 1.0
        if (i >= 0) cart[i] = cart[i].copy(qty = newQty) else cart.add(CartLine(p, 1.0, p.sellPrice))
        if (newQty > p.stockQty) say("Only " + Fmt.qty(maxOf(0.0, p.stockQty)) + " of " + p.name + " in stock. Check your stock count.")
    }

    fun setQty(index: Int, qty: Double) {
        if (index !in cart.indices) return
        if (qty <= 0.0) cart.removeAt(index) else cart[index] = cart[index].copy(qty = qty)
    }

    fun setPrice(index: Int, price: Double) {
        if (index !in cart.indices || price < 0.0) return
        cart[index] = cart[index].copy(price = price)
    }

    /** True while a sale is being sent, so a double tap cannot record it twice. */
    var selling by mutableStateOf(false)
        private set

    fun checkout(method: String, customerId: Long?, note: String, onDone: () -> Unit) {
        val lines = cart.toList()
        if (lines.isEmpty() || selling) return
        val total = lines.sumOf { it.qty * it.price }
        selling = true
        viewModelScope.launch {
            try {
                repo.checkout(lines, method, customerId, note)
                cart.clear()
                say("Sale saved: " + settings.value.symbol + Fmt.money(total))
                onDone()
            } catch (e: ApiException) {
                if (e.offline) say("No internet, so the sale was NOT saved. Connect and try again.")
                else say(e.message ?: "The sale could not be saved.")
            } catch (e: Exception) {
                say("The sale could not be saved: " + (e.message ?: "unknown error"))
            } finally {
                selling = false
            }
        }
    }

    fun signOut() {
        cart.clear()
        auth.signOut()
    }
}
