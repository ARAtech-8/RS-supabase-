@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.CustomerBalance
import com.tuckshop.manager.data.Expense
import com.tuckshop.manager.data.Method
import com.tuckshop.manager.data.NameAmount
import com.tuckshop.manager.data.OwnerTxn
import com.tuckshop.manager.data.Sale
import com.tuckshop.manager.data.SaleItem
import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.net.ApiException
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.ShopSettings
import com.tuckshop.manager.domain.range

// ============================================================================ More menu
@Composable
fun MoreScreen(nav: NavHostController, isOwner: Boolean) {
    val items = if (isOwner) listOf(
        Triple("sales", "Sales history", "See past sales, or cancel one entered by mistake"),
        Triple("expenses", "Running costs (expenses)", "Rent, electricity, transport, wages..."),
        Triple("customers", "Customers on credit", "Who owes you, and take their payments"),
        Triple("suppliers", "Suppliers you owe", "Stock you have not fully paid for"),
        Triple("owner", "Your own money", "Money you put in or took out of the shop"),
        Triple("staff", "Your employees", "Add employees and switch their logins on or off"),
        Triple("activity", "Who did what", "Sales cancelled, stock removed, prices changed..."),
        Triple("settings", "Shop settings and licence", "Shop name, currency, staff rules, move old records"),
        Triple("account", "My account", "Change password, sign out"),
        Triple("help", "What do these words mean?", "Simple explanations of shop money words")
    ) else listOf(
        Triple("sales", "My sales", "Your sales from the last 2 days. You can cancel a sale you made by mistake."),
        Triple("account", "My account", "Change password, sign out"),
        Triple("help", "What do these words mean?", "Simple explanations of shop money words")
    )
    ScreenFrame("More") {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { (route, title, sub) ->
                Card(
                    Modifier.fillMaxWidth().clickable { nav.navigate(route) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(sub, fontSize = 12.sp, color = Ui.Muted)
                    }
                }
            }
        }
    }
}

// ============================================================================ sales history
@Composable
fun SalesHistoryScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val owner = vm.isOwner
    val flow = remember { vm.repo.recentSales(100) }
    val sales by flow.collectAsState(initial = emptyList())
    var selected by remember { mutableStateOf<Sale?>(null) }

    ScreenFrame(if (owner) "Sales history" else "My sales", onBack = onBack, actions = { RefreshAction(vm) }) {
        if (sales.isEmpty()) EmptyHint(if (owner) "No sales yet." else "You have no sales in the last 2 days.")
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(sales, key = { it.id }) { s ->
                Card(
                    Modifier.fillMaxWidth().clickable { selected = s },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(Fmt.dateTime(s.time), fontWeight = FontWeight.Bold)
                            Text(
                                Method.label(s.method) + (if (s.voided) "  |  CANCELLED" else "") +
                                    (if (owner && s.createdByName.isNotBlank()) "  |  " + s.createdByName else ""),
                                fontSize = 12.sp, color = if (s.voided) Ui.Bad else Ui.Muted
                            )
                        }
                        Text(money(s.total), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
    selected?.let { s -> SaleDetailDialog(vm, s) { selected = null } }
}

@Composable
private fun SaleDetailDialog(vm: ShopViewModel, s: Sale, onDismiss: () -> Unit) {
    val items by produceState<List<SaleItem>>(emptyList(), s.id) { value = try { vm.repo.saleItems(s.id) } catch (e: Exception) { value } }
    val who by produceState<String?>(null, s.customerId) { value = try { vm.repo.customerName(s.customerId) } catch (e: Exception) { value } }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sale: " + Fmt.dateTime(s.time), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items.forEach {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(Fmt.qty(it.qty) + " x " + it.name, Modifier.weight(1f))
                        Text(money(it.qty * it.unitPrice))
                    }
                }
                HorizontalDivider()
                Text("Total " + money(s.total) + "  (" + Method.label(s.method) + ")", fontWeight = FontWeight.Bold)
                if (who != null) Text("Customer: $who")
                if (s.createdByName.isNotBlank()) Text("Sold by: " + s.createdByName, fontSize = 12.sp, color = Ui.Muted)
                if (s.voided) Text("This sale was cancelled.", color = Ui.Bad)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            if (!s.voided) TextButton(onClick = { confirm = true }) { Text("Cancel this sale", color = Ui.Bad) }
        }
    )
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Cancel this sale?") },
            text = { Text("The items go back into your stock and the sale is removed from your reports.") },
            confirmButton = {
                Button(onClick = {
                    vm.go("Sale cancelled") { vm.repo.voidSale(s.id) }
                    confirm = false
                    onDismiss()
                }) { Text("Yes, cancel it") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("No") } }
        )
    }
}

// ============================================================================ expenses
private val expenseCategories = listOf(
    "Rent", "Electricity", "Transport", "Wages", "Airtime and data", "Packaging",
    "Fees and licences", "Repairs", "Other"
)

@Composable
fun ExpensesScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val flow = remember { vm.repo.expenses }
    val list by flow.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Expense?>(null) }
    val monthStart = remember { Period.MONTH.range().start }
    val monthTotal = list.filter { it.time >= monthStart }.sumOf { it.amount }

    ScreenFrame("Running costs", onBack = onBack) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Money the shop spends that is not stock: rent, electricity, transport, wages. " +
                    "Spent so far this month: " + money(monthTotal),
                color = Ui.Muted, fontSize = 13.sp
            )
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add an expense") }
        }
        if (list.isEmpty()) EmptyHint("No expenses recorded yet.")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { e ->
                Card(
                    Modifier.fillMaxWidth().clickable { deleting = e },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(e.category, fontWeight = FontWeight.Bold)
                            Text(Fmt.dateTime(e.time) + (if (e.note.isNotBlank()) "  |  " + e.note else ""), fontSize = 12.sp, color = Ui.Muted)
                        }
                        Text(money(e.amount), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    if (adding) {
        var cat by remember { mutableStateOf(expenseCategories[0]) }
        var amount by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        val a = amount.toNum()
        FormDialog(
            "Add an expense", "Save", { adding = false },
            onConfirm = {
                vm.go("Expense saved") { vm.repo.addExpense(cat, a!!, note.trim()) }
                adding = false
            },
            confirmEnabled = a != null && a > 0
        ) {
            ChipChoice(expenseCategories, cat) { cat = it }
            NumInput(amount, { amount = it }, "How much?")
            TextInput(note, { note = it }, "Note (optional)")
        }
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(e.category + "  " + money(e.amount)) },
            text = { Text("Delete this expense? Use this only if you entered it by mistake.") },
            confirmButton = {
                Button(onClick = { vm.go("Deleted") { vm.repo.deleteExpense(e) }; deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Keep it") } }
        )
    }
}

// ============================================================================ customers on credit
@Composable
fun CustomersScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val version by vm.repo.version.collectAsState()
    val customers by vm.customers.collectAsState()
    val balances by produceState<List<CustomerBalance>>(emptyList(), version, customers) { value = try { vm.repo.customerBalances() } catch (e: Exception) { value } }
    var adding by remember { mutableStateOf(false) }
    var paying by remember { mutableStateOf<CustomerBalance?>(null) }

    ScreenFrame("Customers on credit", onBack = onBack) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Total owed to you: " + money(balances.sumOf { maxOf(0.0, it.owed) }),
                fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Text("To put a sale on credit, choose \"On credit\" when you finish a sale.", fontSize = 12.sp, color = Ui.Muted)
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add a customer") }
        }
        if (balances.isEmpty()) EmptyHint("No customers yet.")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(balances, key = { it.customer.id }) { cb ->
                Card(
                    Modifier.fillMaxWidth().clickable { paying = cb },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(cb.customer.name, fontWeight = FontWeight.Bold)
                            if (cb.customer.phone.isNotBlank()) Text(cb.customer.phone, fontSize = 12.sp, color = Ui.Muted)
                        }
                        Text(
                            if (cb.owed > 0.004) "owes " + money(cb.owed) else "settled",
                            fontWeight = FontWeight.Bold, color = if (cb.owed > 0.004) Ui.Warn else Ui.Good
                        )
                    }
                }
            }
        }
    }
    if (adding) NewCustomerDialog({ adding = false }) { n, p ->
        vm.go("Customer added") { vm.repo.addCustomer(n, p) }
        adding = false
    }
    paying?.let { cb ->
        var amount by remember(cb.customer.id) { mutableStateOf(if (cb.owed > 0) Fmt.qty(cb.owed) else "") }
        val a = amount.toNum()
        FormDialog(
            "Payment from " + cb.customer.name, "Save", { paying = null },
            onConfirm = {
                vm.go("Payment recorded") { vm.repo.receivePayment(cb.customer.id, a!!) }
                paying = null
            },
            confirmEnabled = a != null && a > 0
        ) {
            Text("Owes: " + money(cb.owed), color = Ui.Muted)
            NumInput(amount, { amount = it }, "Amount they paid you now")
        }
    }
}

// ============================================================================ suppliers
@Composable
fun SuppliersScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val version by vm.repo.version.collectAsState()
    val owed by produceState<List<NameAmount>>(emptyList(), version) { value = try { vm.repo.supplierBalances() } catch (e: Exception) { value } }
    var paying by remember { mutableStateOf<NameAmount?>(null) }

    ScreenFrame("Suppliers you owe", onBack = onBack) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Total you owe: " + money(owed.sumOf { maxOf(0.0, it.amount) }), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                "When you add stock and say you did not pay in full, the balance shows here. Tap a supplier when you pay them.",
                fontSize = 12.sp, color = Ui.Muted
            )
        }
        if (owed.isEmpty()) EmptyHint("You do not owe any supplier.")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(owed, key = { it.name }) { s ->
                Card(
                    Modifier.fillMaxWidth().clickable { paying = s },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.name, fontWeight = FontWeight.Bold)
                        Text(money(s.amount), fontWeight = FontWeight.Bold, color = Ui.Warn)
                    }
                }
            }
        }
    }
    paying?.let { s ->
        var amount by remember(s.name) { mutableStateOf(Fmt.qty(maxOf(0.0, s.amount))) }
        val a = amount.toNum()
        FormDialog(
            "Pay " + s.name, "Save", { paying = null },
            onConfirm = {
                vm.go("Payment recorded") { vm.repo.paySupplier(s.name, a!!) }
                paying = null
            },
            confirmEnabled = a != null && a > 0
        ) {
            Text("You owe: " + money(s.amount), color = Ui.Muted)
            NumInput(amount, { amount = it }, "Amount you paid now")
        }
    }
}

// ============================================================================ owner's money
@Composable
fun OwnerScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val flow = remember { vm.repo.ownerTxns }
    val list by flow.collectAsState(initial = emptyList())
    var mode by remember { mutableStateOf(0) } // 0 none, 1 put in, 2 took out
    var deleting by remember { mutableStateOf<OwnerTxn?>(null) }

    ScreenFrame("Your own money", onBack = onBack) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Record money you add to the shop (for example to buy stock) and money you take out for yourself. " +
                    "Taking money out is not a shop expense, but it does lower the money in the shop.",
                fontSize = 13.sp, color = Ui.Muted
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { mode = 1 }, modifier = Modifier.weight(1f)) { Text("I put money in") }
                OutlinedButton(onClick = { mode = 2 }, modifier = Modifier.weight(1f)) { Text("I took money out") }
            }
        }
        if (list.isEmpty()) EmptyHint("Nothing recorded yet.")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { t ->
                Card(
                    Modifier.fillMaxWidth().clickable { deleting = t },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(if (t.amount >= 0) "Put in" else "Took out", fontWeight = FontWeight.Bold)
                            Text(Fmt.dateTime(t.time) + (if (t.note.isNotBlank()) "  |  " + t.note else ""), fontSize = 12.sp, color = Ui.Muted)
                        }
                        Text(money(t.amount), fontWeight = FontWeight.Bold, color = if (t.amount >= 0) Ui.Good else Ui.Bad)
                    }
                }
            }
        }
    }
    if (mode != 0) {
        var amount by remember(mode) { mutableStateOf("") }
        var note by remember(mode) { mutableStateOf("") }
        val a = amount.toNum()
        FormDialog(
            if (mode == 1) "Money you put in" else "Money you took out", "Save", { mode = 0 },
            onConfirm = {
                val signed = if (mode == 1) a!! else -a!!
                vm.go("Saved") { vm.repo.addOwnerTxn(signed, note.trim()) }
                mode = 0
            },
            confirmEnabled = a != null && a > 0
        ) {
            NumInput(amount, { amount = it }, "How much?")
            TextInput(note, { note = it }, "Note (optional)")
        }
    }
    deleting?.let { t ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(money(t.amount)) },
            text = { Text("Delete this entry? Use this only if you entered it by mistake.") },
            confirmButton = {
                Button(onClick = { vm.go("Deleted") { vm.repo.deleteOwnerTxn(t) }; deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Keep it") } }
        )
    }
}

// ============================================================================ shop settings
@Composable
fun SettingsScreen(vm: ShopViewModel, st: AuthState.In, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val current by vm.settings.collectAsState()
    var name by remember { mutableStateOf(current.shopName) }
    var symbol by remember { mutableStateOf(current.symbol) }
    var opening by remember { mutableStateOf(if (current.openingMoney == 0.0) "" else Fmt.qty(current.openingMoney)) }
    var allowCredit by remember { mutableStateOf(st.shop.allowEmployeeCredit) }
    var saving by remember { mutableStateOf(false) }

    ScreenFrame("Shop settings", onBack = onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            WhiteCard {
                SectionTitle("Your shop")
                TextInput(name, { name = it }, "Shop name")
                TextInput(symbol, { symbol = it }, "Currency symbol (for example \$ or ZiG)")
                NumInput(
                    opening, { opening = it }, "Money in the shop when you started using this app",
                    hint = "Cash and mobile money together. Used for the cash flow statement."
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Employees may sell on credit", fontWeight = FontWeight.Bold)
                        Text("Turn off if you want only yourself to give credit.", fontSize = 12.sp, color = Ui.Muted)
                    }
                    Switch(checked = allowCredit, onCheckedChange = { allowCredit = it })
                }
                Button(
                    onClick = {
                        saving = true
                        scope.launch {
                            try {
                                vm.repo.updateShop(name.trim(), symbol.trim(), opening.toNum() ?: 0.0, allowCredit)
                                vm.auth.reload()
                                vm.say("Settings saved")
                            } catch (e: ApiException) {
                                vm.say(e.message ?: "Could not save.")
                            } finally {
                                saving = false
                            }
                        }
                    },
                    enabled = !saving,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Save settings") }
            }
            WhiteCard {
                SectionTitle("Your Shop Code", "Employees need this code to sign in. Your licence key is also made from it.")
                Text(st.shop.code, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            MigrateCard(vm, st)
            val trial = LocalTrialMsLeft.current
            Text(
                if (trial == null) "Licence: full version unlocked for this shop."
                else "Free trial: " + trialText(trial) + ". WhatsApp " + com.tuckshop.manager.domain.License.WHATSAPP_DISPLAY + " to get key.",
                fontSize = 12.sp, color = Ui.Muted
            )
            Text("Tuck Shop Manager 2.0. Your records are saved online and can be used on more than one phone.", fontSize = 12.sp, color = Ui.Muted)
        }
    }
}

// ============================================================================ glossary
@Composable
fun HelpScreen(onBack: () -> Unit) {
    val terms = listOf(
        "Turnover / Sales / Revenue" to "All the money your sales brought in. Not the same as profit.",
        "Cost of sales" to "What you paid for the items you sold.",
        "Gross profit" to "Sales minus the cost of the items you sold. What the goods earned you.",
        "Expenses" to "Money the shop spends to run, like rent, electricity, transport and wages.",
        "Net profit" to "What is really left: sales, minus the cost of goods, minus expenses and stock losses. This is the number that matters.",
        "Loss" to "When your costs are more than your sales. The shop lost money in that period.",
        "Margin" to "The part of each 100 you sell that is profit. A margin of 25% means you keep 25 out of every 100.",
        "Cash flow" to "Where the money actually moved: what came in and what went out. A credit sale is a sale, but it is not cash until the customer pays.",
        "Stock value" to "What the items on your shelves cost you to buy.",
        "Average cost" to "When you buy the same item at different prices, the app mixes them to work out one fair buying price.",
        "Debtors" to "Customers who owe you money.",
        "Creditors" to "Suppliers you owe money to.",
        "Net worth" to "Everything the shop has (money, stock, what customers owe) minus what it owes."
    )
    ScreenFrame("What do these words mean?", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            terms.forEach { (t, d) ->
                WhiteCard {
                    Text(t, fontWeight = FontWeight.Bold)
                    Text(d, fontSize = 14.sp)
                }
            }
        }
    }
}
