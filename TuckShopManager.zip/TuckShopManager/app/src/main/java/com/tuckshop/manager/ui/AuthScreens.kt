@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.net.ApiException
import kotlinx.coroutines.launch

@Composable
fun LoadingScreen(text: String = "Loading...") {
    Column(
        Modifier.fillMaxSize().systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator()
        Text(text, Modifier.padding(top = 16.dp), color = Ui.Muted)
    }
}

@Composable
fun FailedScreen(vm: ShopViewModel, message: String) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text("Tuck Shop Manager", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ui.Good)
        Text(message, textAlign = TextAlign.Center)
        Button(onClick = { scope.launch { vm.auth.retry() } }, modifier = Modifier.fillMaxWidth()) { Text("Try again") }
        OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}

@Composable
fun PasswordField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier.fillMaxWidth()) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show", fontSize = 12.sp) } },
        modifier = modifier
    )
}

private enum class Mode { OWNER_IN, OWNER_NEW, STAFF }

@Composable
fun LoginScreen(vm: ShopViewModel) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(Mode.OWNER_IN) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var shopName by remember { mutableStateOf("") }
    var yourName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun run(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            try {
                block()
            } catch (e: ApiException) {
                error = e.message
            } catch (e: Exception) {
                error = "Something went wrong: " + (e.message ?: "unknown error")
            } finally {
                busy = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
    ) {
        Text("Tuck Shop Manager", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ui.Good)
        Text("Sign in to your shop", color = Ui.Muted)

        ChipChoice(
            listOf("Owner", "New shop", "Employee"),
            when (mode) { Mode.OWNER_IN -> "Owner"; Mode.OWNER_NEW -> "New shop"; Mode.STAFF -> "Employee" }
        ) {
            mode = when (it) { "Owner" -> Mode.OWNER_IN; "New shop" -> Mode.OWNER_NEW; else -> Mode.STAFF }
            error = null
        }

        when (mode) {
            Mode.OWNER_IN, Mode.OWNER_NEW -> {
                if (mode == Mode.OWNER_NEW) {
                    Text(
                        "Create the owner account for your shop. You can then add your employees inside the app.",
                        fontSize = 12.sp, color = Ui.Muted
                    )
                    OutlinedTextField(
                        shopName, { shopName = it }, label = { Text("Shop name") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        yourName, { yourName = it }, label = { Text("Your name") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    email, { email = it }, label = { Text("Your email") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )
                PasswordField(password, { password = it }, if (mode == Mode.OWNER_NEW) "Choose a password (6+ characters)" else "Password")
                Button(
                    onClick = {
                        run {
                            if (mode == Mode.OWNER_NEW) vm.auth.ownerSignUp(email, password, shopName, yourName)
                            else vm.auth.ownerSignIn(email, password)
                        }
                    },
                    enabled = !busy && email.contains("@") && password.length >= 6 &&
                        (mode == Mode.OWNER_IN || shopName.isNotBlank()),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Please wait..." else if (mode == Mode.OWNER_NEW) "Create my shop" else "Sign in") }
            }
            Mode.STAFF -> {
                Text("Ask your employer for the shop code, your username and your password.", fontSize = 12.sp, color = Ui.Muted)
                OutlinedTextField(
                    code, { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, label = { Text("Shop code") },
                    singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    username, { username = it.lowercase().filter { c -> !c.isWhitespace() } }, label = { Text("Username") },
                    singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                    modifier = Modifier.fillMaxWidth()
                )
                PasswordField(password, { password = it }, "Password")
                Button(
                    onClick = { run { vm.auth.staffSignIn(code, username, password) } },
                    enabled = !busy && code.length == 6 && username.length >= 3 && password.length >= 6,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Please wait..." else "Sign in") }
            }
        }

        val notice by vm.auth.notice.collectAsState()
        (error ?: notice)?.let { Text(it, color = Ui.Bad, textAlign = TextAlign.Center) }
        Text(
            "Needs an internet connection. Your shop's records are saved online so they are safe if you lose your phone.",
            fontSize = 11.sp, color = Ui.Muted, textAlign = TextAlign.Center
        )
    }
}

/** Signed in, but not attached to a shop: owner can create one; an employee sees why they are locked out. */
@Composable
fun NoAccessScreen(vm: ShopViewModel, staff: Boolean) {
    val scope = rememberCoroutineScope()
    var shopName by remember { mutableStateOf("") }
    var yourName by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
    ) {
        Text("Tuck Shop Manager", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ui.Good)
        if (staff) {
            Text("This login is switched off.", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Please ask your employer to switch it back on.", textAlign = TextAlign.Center)
        } else {
            Text("One more step: set up your shop", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(shopName, { shopName = it }, label = { Text("Shop name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(yourName, { yourName = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        try {
                            vm.auth.createShopNow(shopName, yourName)
                        } catch (e: ApiException) {
                            error = e.message
                        } finally {
                            busy = false
                        }
                    }
                },
                enabled = !busy && shopName.isNotBlank(), modifier = Modifier.fillMaxWidth()
            ) { Text("Create my shop") }
            val notice by vm.auth.notice.collectAsState()
            (error ?: notice)?.let { Text(it, color = Ui.Bad) }
        }
        OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}
